//基础配置
const Config = {
    aad: '769a3784-ffac-401b-a723-42151c485099',
    client_id: '77e0d220-7944-4afb-b383-f73784659bc4',
    client_secret: '6mdQ_Mdm@Qj1q.7uKan@SWDc5DZuqK0w',
    userId: '1cf2b73f-0a73-417a-9c66-6fddde294dad',
    redirect_uri: 'http://localhost:3000/callback'
}

export default Config;