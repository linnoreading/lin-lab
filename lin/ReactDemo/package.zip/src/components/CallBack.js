import React from 'react';
import { withRouter } from 'react-router-dom';
import common from '../assets/script/Common';


class CallBack extends React.Component {
    constructor(props) {
        super(props);
        console.log("callback.");
    }
    componentWillMount() {
        debugger;
        let code = common.getUrlParmByName('code');

        console.log(code);
    }

    render() {
        return (
            <div id='callback'>callback</div>
        );
    }
}


export default withRouter(CallBack);