import React from 'react';
import Config from '../assets/script/Config';
import qs from 'qs';

class O365 extends React.Component {
    constructor(props) {
        super(props);

    }

    getToken = () => {
        let data = {
            'client_id': Config.client_id,
            'response_type': 'code',
            "redirect_uri": Config.redirect_uri,
            "response_mode": "query",
            "scope": "user.read",
            "state": 12345
        }
        //console.log(data);
        let strData = qs.stringify(data);
        console.log(data);
        let url = "https://login.microsoftonline.com/" + Config.aad + "/oauth2/v2.0/authorize?" + strData;
        //debugger;
        window.location.href = url;
    }

    render() {
        return (
            <div>
                <h2>This is O365 Test.</h2>
                <a onClick={this.getToken}>Get O365 Token</a>
            </div>
        );
    }
}

export default O365;