import React from 'react';
import axios from 'axios';
import './../assets/css/App.css';
import Clock from './Clock';
import O365 from './O365';

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      name: 'fenghailin',
      element1: <div><input value='123' /><img src='https://loremflickr.com/200/200' alt='test' /></div>,
      isToggleOn: true
    };
  }

  //toggle 测试，注意确保回调函数正确绑定了this
  //https://react.docschina.org/docs/handling-events.html
  toggleTest = () => {
    console.log(this)
    this.setState({
      isToggleOn: !this.state.isToggleOn
    })
  }

  getSite = () => {
    var siteUrl = 'https://www.hpi.com.cn/';
    axios.get(siteUrl).then(res => {
      console.log(res);
    })
  }

  render() {
    var name2 = 'test';
    return (
      <div className="App">
        <h1>hello.{this.state.name}</h1>
        <h2>{(new Date()).now}</h2>
        <h3>{name2}</h3>
        <input type='button' value={this.state.isToggleOn} onClick={this.toggleTest} />
        <a href='#' onClick={this.getSite}>Get SPS</a>

        <O365 />


        <Clock />
        <Clock />
        <Clock />

      </div >
    );
  }
}

export default App;


